<?php

    // Funcionamento para Web (phpMyAdmin)
    // $dbHost = 'localhost';
    // $dbUsername = 'id18633594_pedro_souza';
    // $dbPassword = 'o!tnM{w1ir(fq^LT';
    // $dbName = 'id18633594_ticketclick';

    //Funcionamento para localhost (xamp)

    $dbHost = 'localhost';
    $dbUsername = 'root';
    $dbPassword = '';
    $dbName = 'TicketClick';

    $conexao = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);

    // if($conexao->connect_error)
    // {
    //     echo "Erro";
    // }
    // else
    // {
    //     echo "Conexão efetuada com sucesso!";
    // }


?>