<?php

    //Localhost

    $localhost = "localhost";
    $user = "root";
    $passw = "";
    $banco = "TicketClick";
// 
    global $pdo;

    try {
        $pdo = new PDO("mysql:dbname=".$banco."; host=".$localhost, $user, $passw);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
    } catch(PDOException $e) {
        echo "ERRO: ".$e->getMessage();
        exit;
    }

    // Servidor Web

    // $localhost = "localhost";
    // $user = "id18633594_pedro_souza";
    // $passw = "o!tnM{w1ir(fq^LT";
    // $banco = "id18633594_ticketclick";

    // global $pdo;

    // try {
    //     $pdo = new PDO("mysql:dbname=".$banco."; host=".$localhost, $user, $passw);
    //     $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
    // } catch(PDOException $e) {
    //     echo "ERRO: ".$e->getMessage();
    //     exit;
    // }
?>