<!DOCTYPE html>
<html lang="en">
  <head>
    <title>TicketClick</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.0/jquery.min.js"></script>

    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/cookie.css">
    <link rel="stylesheet" href="css/cookie2.css">
    <link rel="shortcut icon" sizes="250x100" href="icons/icone-ticket.ico">

  </head>
  <body>

      

    <header class="menu-nav">
      <nav class="container navbar navbar-expand-md navbar-dark">
        <a href="index.php" class="navbar-brand">
          <img src="img/ticketclick.svg" alt="TicketClick">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Abrir Navegação">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="login_convidado.php">Login</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="cadastro_convidado.php">Inscrever-se</a>
            </li>
            <li class="nav-item">
              <a class="btn-menu btn ml-md-2" id="scrollSuave" href="#organizador">Seja um organizador</a>
            </li>
          </ul>
        </div>  
      </nav>
    </header>
    <container>
      <style>
        .imagem{
          max-width: 100%;
        }
      </style>
      <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
          <!-- <div class="carousel-item">
            <div class="bg-header">
            <a href="#operador">
            <center><img class="imagem" src="img/validador.avif" alt="Festa"></center>
            </a>
            <p>Torne-se um operador e trabalhe juntamente com o organizador do evento! Clique para saber mais!</p>
            </div>
          </div> -->
          <div class="carousel-item active">
            <div class="bg-header">
            <a>
            <center><img class="imagem" src="img/da.jpg" alt="Festa"></center>
            </a>
            <p>TicketClick - Seu ingresso em um Click!</p>
            </div>
          </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Anterior</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Próximo</span>
        </a>
      </div>
    </container>
    <section class="container eventos">
      <h1>Eventos em destaque</h1>
        <input type="text" id="txtBusca" onkeyup="pesquisar()" placeholder="Buscar..."/>
      <br>
      <br>
      <br>
      <style>
        .imagem_evento {
          width:100%;
        }
      </style>
      <div class="row">
    <?php

          include_once('config.php');

          $result_eventos = "SELECT * FROM eventos";
          $resultado_eventos = mysqli_query($conexao, $result_eventos);
          
        ?>
      <div class="container">
        <ul class="row evento-lista" id="menu">
        <?php while($row_usuario = mysqli_fetch_assoc($resultado_eventos)) { ?>
          <li class="evento-item col-4">
            <img src="img/<?php echo $row_usuario['foto_evento'];?>" alt="Imagem do evento" class="imagem_evento">
            <a href="eventos/aedb.php"><?php echo $row_usuario['nome_evento'];?></a>
            <input type="hidden" value="<?php echo $row_usuario['ID_evento'];?>">
          </li>
          <!-- <li class="evento-item col-4">
            <img src="img/evento2.png" alt="Evento 2" class="imagem_evento">
            <a href="eventos/lollapalooza.php">Lollapalooza</a>
          </li>
          <li class="evento-item col-4">
            <img src="img/evento3.png" alt="Evento 3" class="imagem_evento">
            <a href="eventos/exapicor.php">Exapicor</a>
          </li>
          <li class="evento-item col-4">
            <img src="img/evento4.png" alt="Evento 4" class="imagem_evento">
            <a href="eventos/celeiro.php">Celeiro</a>
          </li> --> 
          <?php
          }
        ?>
        </ul>
       
            </div>
            <!-- /.card-body -->
          </div><br>
          <!-- /.card -->
        </div>
      </div>
    </section>
      <style>
        .imagem_evento {
          width:100%;
          
            Height: 70%;
        }

      </style>


<div class="container">

        <ul class="row evento-lista" id="menu">
                                                          <hr></hr>
                                        <center>  <h1>Casas Noturnas</h1>   </center>    

<hr>

          <li class="evento-item col-4">
            <img src="img/rockinrio.png" alt="Evento 4" class="imagem_evento">
            <a href="eventos/celeiro.php">Rock in Rio</a>
          </li>

          <li class="evento-item col-4">
            <img src="img/r6.jpg" alt="Evento 8" class="imagem_evento">
            <a href="eventos/r6.php">R6</a>
          </li>
          
          <li class="evento-item col-4">
            <img src="img/tontina.png" alt="Evento 9" class="imagem_evento">
            <a href="eventos/tontina.php">Tontina</a>
          </li>


</hr>

                                                            <hr></hr> 
                                        <center>  <h1>Eventos de Game e Animes</h1>   </center>    

         
<hr>
          <li class="evento-item col-4">
            <img src="img/evento6.png" alt="Evento 6" class="imagem_evento">
            <a href="eventos/animesummit.php">Anime-Summit</a>
          </li> 
  
          <li class="evento-item col-4">
            <img src="img/evento5.jpg" alt="Evento 5" class="imagem_evento">
            <a href="eventos/bgs.php">BGS</a>
          </li>


          <li class="evento-item col-4">
            <img src="img/ComicCon.jpg" alt="Evento 10" class="imagem_evento">
            <a href="eventos/ComicCon.php">Comic-Con</a>
          </li>



</hr> 
                                                              <hr></hr>
                                        <center>  <h1>Eventos de Exposição em Geral </h1>   </center>    
                                                              

<hr>
          
          <li class="evento-item col-4">
            <img src="img/evento3.png" alt="Evento 3" class="imagem_evento">
            <a href="index.php">Disponivel no Proximo Ano</a>
          </li>


          <li class="evento-item col-4">
            <img src="img/flir.jpg" alt="Evento 5" class="imagem_evento">
            <a href="eventos/flir.php">FLIR</a>
          </li>


          <li class="evento-item col-4">
            <img src="img/museu.png" alt="Evento 5" class="imagem_evento">
            <a href="eventos/museu.php">Museu do Amanhã</a>
          </li>
         
</hr>




                                                          <hr></hr>   
                                        <center>  <h1>Eventos de Teatro</h1>   </center>    




<hr>

          <li class="evento-item col-4">
            <img src="img/evento7.jpg" alt="Evento 7" class="imagem_evento">
            <a href="index.php">Ingressos Esgotado </a>
          </li>



          <li class="evento-item col-4">
            <img src="img/curitiba.png" alt="Evento 5" class="imagem_evento">
            <a href="index.php">Ingressos Esgotado</a>
          </li>


          <li class="evento-item col-4">
            <img src="img/aman.jpg" alt="Evento 5" class="imagem_evento">
            <a href="eventos/aman.php">Teatro da Aman</a>
          </li>







</hr>


        </ul>
    </section>








      <!-- Codigo txt  (codigo_index)



                 Aqui  -->
            <!-- /.card-body -->
          </div><br>
          <!-- /.card -->
        </div>
      </div>
    </section>
    <section class="organizador" id="organizador">
      <h2>Seja um organizador</h2>
      <div class="card-index">
        <div class="row container">
          <div class="col-lg">
            <h3 class="tit-org">Por que acreditamos que não é só organizar um evento, mas momentos.</h3>
            <br>
            <br>
            <ul class="">
              <li>
                <img class="marcador" src="icons/icone-ticket.ico" alt="ticket">
                <h5>Melhor exposição do seu evento. </h5>
              </li>
              <li>
                <img class="marcador" src="icons/icone-ticket.ico" alt="ticket">
                <h5>Centralização da venda de ingressos. </h5>
              </li>
              <li>
                <img class="marcador" src="icons/icone-ticket.ico" alt="ticket">
                <h5>Controle de convidados. </h5>
              </li>
              <li>
                <img class="marcador" src="icons/icone-ticket.ico" alt="ticket">
                <h5>Preço justo.</h5>
              </li><br>
              <center><img class="imagem_organizador1" src="img/bg-organizador-index.png" alt=""></center>
                <input type="submit" value="" class="btn btn-outline-link btn-lg btn-block">
                <a class="btn btn-success btn-lg btn-block" href="cadastro_organizador.php">Saiba Mais!</a>
            </ul>
          </div>
          </section>
          <style>
            .imagem_organizador1 {
              max-width: 100%;
              float: left;
              border-radius: 10px;
            }
          </style>
        </div>
      </div>
    </section>
    <br>
    <section class="organizador" id="operador">
      <h2>Seja um operador</h2>
      <div class="card-index">
        <div class="row container">
          <div class="col-lg">
            <h3 class="tit-org">Torne-se um operador! Valide por código ou por QR Code!</h3>
            <br>
            <br>
            <ul class="">
              <li>
                <img class="marcador" src="icons/icone-ticket.ico" alt="ticket">
                <h5>Melhor organização do evento. </h5>
              </li>
              <li>
                <img class="marcador" src="icons/icone-ticket.ico" alt="ticket">
                <h5>Controle de entrada dos convidados. </h5>
              </li>
              <li>
                <img class="marcador" src="icons/icone-ticket.ico" alt="ticket">
                <h5>Trabalhe juntamente com o organizador do evento.</h5>
              </li>
              <li>
                <img class="marcador" src="icons/icone-ticket.ico" alt="ticket">
                <h5>Rápido e prático.</h5>
              </li><br>
              <img class="imagem_organizador2" src="img/validador.avif" alt="">
              <input type="submit" value="" class="btn btn-outline-link btn-lg btn-block">
                <a class="btn btn-success btn-lg btn-block" href="cadastro_organizador.php">Saiba Mais!</a>
            </ul>
          </div>
          </section>
          <style>
            .imagem_organizador2 {
              max-width: 100%;
              float: left;
              border-radius: 10px;
            }
          </style>
        </div>
      </div>
    </section>
    <br>
    <!-- Footer -->
  <footer class="text-center text-lg-start bg-dark text-muted">
  <!-- Section: Social media -->
    <section
      class="d-flex justify-content-center justify-content-lg-between p-4 border-bottom"
    >
      <!-- Left -->
      <div class="me-5 d-none text-white d-lg-block">
        <span>Saiba mais sobre nós:</span>
      </div>
      <!-- Left -->

      <!-- Right -->
      <div>
        <a href="" class="me-4 text-reset">
          <i class="fab fa-facebook-f"></i>
        </a>
        <a href="" class="me-4 text-reset">
          <i class="fab fa-twitter"></i>
        </a>
        <a href="https://mail.google.com/mail/u/2/#inbox" class="me-4 text-reset">
          <i class="fab fa-google"></i>
        </a>
        <a href="" class="me-4 text-reset">
          <i class="fab fa-instagram"></i>
        </a>
        <a href="" class="me-4 text-reset">
          <i class="fab fa-linkedin"></i>
        </a>
        <a href="https://github.com/pedr4souz4/ticketclick" class="me-4 text-reset">
          <i class="fab fa-github"></i>
        </a>
      </div> 
      <!-- Right -->
    </section>
    <!-- Section: Social media -->

    <!-- Section: Links  -->
    <section class="">
      <div class="container text-md-start mt-5">
        <!-- Grid row -->
        <div class="row mt-3">
          <!-- Grid column -->
          <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">
            <!-- Content -->
            <h6 class="text-uppercase text-white fw-bold mb-4">
            <!-- <img src="icons/diamond.svg"></img> TicketClick -->
            <i class="fas fa-gem me-1"></i> TicketClick
            </h6>
            <p class="text-white">
            O <strong>TicketClick</strong> é um site em desenvolvimento que tem a finalidade 
            de fazer um sistema de controle de acesso em eventos gerais, para inutilizar as listas de presença e ingressos em papel. 
            A validação do ingresso será feita tanto pelo celular via QR Code ou manual pelo site.
            </p>
          </div>
          <!-- Grid column -->

          <!-- Grid column -->
          <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
            <!-- Links -->
            <h6 class="text-uppercase text-white fw-bold mb-4">
              Contato
            </h6>
            <p class="text-white"><i class="fas fa-home text-white me-3"></i> Resende, RJ</p>
            <p class="text-white"><i class="fas fa-envelope me-3"></i>ticketclick0@gmail.com</p>
            <p class="text-white"><i class="fas fa-phone me-3"></i> + 24 999 99 99</p>
            <p class="text-white"><i class="fas fa-envelope-open me-3"></i><a href="contato.php" class="text-reset"><u>Contate-nos</u></a></p>
          </div>
          <!-- Grid column -->
        </div>
        <!-- Grid row -->
      </div>
    </section>
    <!-- Section: Links  -->

    <!-- Copyright -->
    <div class="text-center text-white p-4" style="background-color: rgba(0, 0, 0, 0.05);">
      © 2022 Copyright:
      <a class="text-reset fw-bold" href="http://ticketclick.000webhostapp.com/">ticketclick.000webhostapp.com/</a>
    </div>
    <!-- Copyright -->
  </footer>
  <!-- Footer -->
  <!-- cookies start -->

  <div class="wrapper">
    <img src="img/cookie.png" alt="Cookie">
    <div class="content">
      <header>Política de Cookie</header>
      <p>Esse site usa cookies para garantir que você tenha amelhor experiência no nosso site.</p>
      <div class="buttons">
        <button class="item">Eu entendo</button>
        <a href="#" class="item">Saiba mais</a>
      </div>
    </div>
  </div>
  <script>
    const cookieBox = document.querySelector(".wrapper"),
    acceptBtn = cookieBox.querySelector("button");
    acceptBtn.onclick = ()=>{
      //setting cookie for 1 month, after one month it'll be expired automatically
      document.cookie = "CookieBy=CodingNepal; max-age="+60*60*24*30;
      if(document.cookie){ //if cookie is set
        cookieBox.classList.add("hide"); //hide cookie box
      }else{ //if cookie not set then alert an error
        alert("Cookie can't be set! Please unblock this site from the cookie setting of your browser.");
      }
    }
    let checkCookie = document.cookie.indexOf("CookieBy=CodingNepal"); //checking our cookie
    //if cookie is set then hide the cookie box else show it
    checkCookie != -1 ? cookieBox.classList.add("hide") : cookieBox.classList.remove("hide");
  </script>

<!-- cookies end -->
      <script>
        var $doc = $('html, body');
        $('#scrollSuave').click(function() {
          $doc.animate({
              scrollTop: $( $.attr(this, 'href') ).offset().top
          }, 500);
          return false;
        });
    </script>
    <script type="text/javascript" src="js/jquery-3.2.1.slim.min.js"></script>
    <script type="text/javascript" src="js/popper.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.js"></script>
    <script type="text/javascript" src="js/app.js"></script>
    <script type="text/javascript" src="js/pesquisar.js"></script>
    <script type="text/javascript" src="js/cookie.js"></script>
  </body>
</html>
 