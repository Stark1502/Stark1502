<?php
  require '../verifica_organizador.php';
  if(isset($_SESSION['idUser']) && !empty($_SESSION['idUser'])):
?>

<!DOCTYPE html>
<html>
  <head>
    <title>TicketClick - Editar evento</title>
    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css">

    <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>

    <link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="shortcut icon" sizes="250x100" href="../icons/icone-ticket.ico">

    <script>
		function goBack() {
			window.history.back()
		}
		</script>
    
  </head>
  <body>
    <header class="menu-nav">
      <nav class="container navbar navbar-expand-md navbar-dark">
        <a href="../index_organizador.php" class="navbar-brand">
          <img src="../img/ticketclick.svg" alt="TicketClick">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Abrir Navegação">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto">
          <a style="color: grey;" class="nav-link" href="">(Organizador)</a>
            <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo $nomeUser; ?></a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="perfil/perfil_organizador.php">Minha Conta</a>
              <a class="dropdown-item" href="organizador/meusEventos.php">Meus Eventos</a>
              <a class="dropdown-item" href="">Promoções</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="../sair.php">Sair</a>
            </div>
            </li>
          </ul>
        </div>   
      </nav>
    </header>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1>Editar Evento</h1>
            </div>
          </div>
        </div><!-- /.container-fluid -->
      </section>
      <a class="btn-menu btn ml-md-2" href="#organizador" onclick="goBack()">Voltar</a>

      <!-- Main content --> 
      <section class="content">
        <div class="container">
        <?php
          include('../perfil/conexao.php');
          
          /*$id = filter_input(INPUT_GET,'id',FILTER_DEFAULT);

        $select = "SELECT * FROM tb_contatos WHERE id_contatos=:id";
          try{
              $resultado = $conect->prepare($select);
              $resultado->bindParam(':id',$id, PDO::PARAM_INT);
              $resultado->execute();

              $contar = $resultado->rowCount();
              if($contar>0){
                  while($show = $resultado->FETCH(PDO::FETCH_OBJ)){
                      $idCont = $show->id_contatos;
                      $nome = $show->nome_contatos;
                      $fone = $show->fone_contatos;
                      $email = $show->email_contatos;
                      $foto = $show->foto_contatos;
                  }
              }else{
                  echo '<div class="alert alert-danger">Não há dados com o id informado!</div>';
              }
          }catch(PDOException $e){
              echo "<strong>ERRO DE SELECT NO PDO: </strong>".$e->getMessage();
          }*/
        ?>
            <!-- left column -->
            <div class="col-lg">
              <!-- general form elements -->
              <div class="card card-primary">
                <div class="card-header">
                  <h3 class="card-title">1 - Informações Básicas</h3>
                  <h6>Adicione as informações básicas do evento.</h6>
                </div>
                <!-- /.card-header -->
                <!-- form start -->
                <form role="form" action="" method="post" enctype="multipart/form-data">
                  <div class="card-body">
                  <?php
                  include_once('../config.php');
                  $result = mysqli_query($conexao, "SELECT * FROM eventos WHERE ID_evento = 35");
                  $row = $result->fetch_assoc();
                  ?>
                    <div class="form-group">
                      <label for="exampleInputEmail1">Nome do Evento *</label>
                      <input type="text" class="form-control" maxlength="100" placeholder="Nome do Evento..." name="nome_evento" id="nome_evento" value="<?php echo $row['nome_evento']; ?>" required>
                    </div>
                    <div class="inline-block">
                      <div class="form-group">
                        <label for="exampleInputEmail1">Data Início *</label>
                        <input type="date" class="form-control" name="data_inicio" id="data_inicio" value="<?php echo $row['data_inicio']; ?>" required>
                      </div>
                    </div>
                    <div class="inline-block">
                      <div class="form-group">
                        <label for="exampleInputEmail1">Hora Início *</label>
                        <input type="time" class="form-control" name="hora_inicio" id="hora_inicio" value="<?php echo $row['hora_inicio']; ?>" required>
                      </div>
                    </div>
                    <br>
                    <div class="inline-block">
                      <div class="form-group">
                        <label for="exampleInputEmail1">Data Término *</label>
                        <input type="date" class="form-control" name="data_termino" id="data_termino" value="<?php echo $row['data_termino']; ?>" required>
                      </div>
                    </div>
                    <div class="inline-block">
                      <div class="form-group">
                        <label for="exampleInputEmail1">Hora Término *</label>
                        <input type="time" class="form-control" name="hora_termino" id="hora_termino" value="<?php echo $row['hora_termino']; ?>" required>
                      </div>
                    </div>
                    <div class="form-group" id="descricao_evento">
                      <label for="exampleInputEmail1">Descrição (opcional)</label>
                      <input style="height:250px; width:100%" maxlength="250" placeholder="Adicione aqui a descrição do evento..." type="text" class="descricao_evento" name="descricao" id="descricao" value="<?php echo $row['descricao']; ?>"></input>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        </div>
      </section>
      <style>
        .content {
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .form-control {
          padding: 10px 20px 10px 10px;
          max-width: 500px;
        }

        .descricao_evento {
          padding: 10px 20px 10px 10px;
          max-width: 100%;
        }

        .descricao_local {
          padding: 10px 20px 10px 10px;
          max-width: 100%;
        }

        .inline-block {
          width: 250px;
          height: 100px;
          display: inline-block;
        }
      </style>
      <br>
      <section class="content2">
        <div class="container">
            <!-- left column -->
            <div class="col-lg">
              <!-- general form elements -->
              <div class="card card-primary">
                <div class="card-header">
                  <h3 class="card-title">2 - Local do Evento</h3>
                  <h6>Adicione as principais informações do evento.</h6>
                </div>
                <!-- /.card-header -->
                <!-- form start -->
                <form role="form" action="" method="post" enctype="multipart/form-data">
                  <div class="card-body">
                    <div class="form-group">
                      <label for="exampleInputEmail1">Nome do Local *</label>
                      <input type="text" class="form-control" maxlength="100" placeholder="Nome do Local..." name="nome_local" id="nome_local" value="<?php echo $row['nome_local']; ?>" required>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail1">CEP *</label>
                      <input type="text" class="form-control" name="cep" id="cep" maxlength="8" placeholder="00.000-000" onblur="pesquisacep(this.value);" value="<?php echo $row['CEP'] ?>" required>
                    </div>
                    <div class="inline-block">
                      <div class="form-group">
                        <label for="exampleInputEmail1">Rua *</label>
                        <input type="text" class="form-control" name="rua" id="rua" value="<?php echo $row['rua']; ?>" readonly required>
                      </div>
                    </div>
                    <div class="inline-block">
                      <div class="form-group">
                        <label for="exampleInputEmail1">Bairro *</label>
                        <input type="text" class="form-control" maxlength="50" name="bairro" id="bairro" value="<?php echo $row['bairro']; ?>" readonly required>
                      </div>
                    </div>
                    <br>
                    <div class="inline-block">
                      <div class="form-group">
                        <label for="exampleInputEmail1">Número</label>
                        <input type="text" class="form-control" maxlength="10" name="numero" id="numero" value="<?php echo $row['numero']; ?>" required>
                      </div>
                    </div>
                    <div class="inline-block">
                      <div class="form-group">
                        <label for="exampleInputEmail1">Complemento (opcional)</label>
                        <input type="text" class="form-control" maxlength="100" name="complemento" id="complemento" value="<?php echo $row['complemento']; ?>">
                      </div>
                    </div>
                    <br>
                    <div class="inline-block">
                      <div class="form-group">
                        <label for="exampleInputEmail1">Cidade *</label>
                        <input type="text" class="form-control" name="cidade" id="cidade" value="<?php echo $row['cidade']; ?>" readonly required>
                      </div>
                    </div>
                    <div class="inline-block">
                      <div class="form-group">
                        <label for="exampleInputEmail1">Estado *</label>
                        <input type="text" class="form-control" name="estado" id="estado" value="<?php echo $row['estado']; ?>" readonly required>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <style>
        .content2 {
          display: flex;
          align-items: left;
          justify-content: left;
        }

        .custom-file-input {
          padding: 10px 100px 10px 50px;
          max-width: 1000px;
        }
      </style>
      <br>
      <section class="content3">
        <div class="container">
          <!-- left column -->
          <div class="col-lg">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">3 - Ingressos</h3>
                <h6>Defina os tipos de ingressos.</h6>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form role="form" action="" method="post" enctype="multipart/form-data">
                <div class="card-body">
                  <div class="inline-block">
                    <div class="form-group">
                      <label for="exampleInputEmail1">Ingresso Gratuito</label>
                      <input type="checkbox" name="scale" id="scale" required>
                    </div>
                  </div>
                  <div class="inline-block">
                    <div class="form-group">
                      <label for="exampleInputEmail1">Ingresso Pago</label>
                      <input type="checkbox" name="scale" id="scale" required>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <style>
        .content3 {
          display: flex;
          align-items: left;
          justify-content: left;
        }
      </style>
      <br>
      <section class="content4">
        <div class="container">
          <!-- left column -->
          <div class="col-lg">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">4 - Organizador</h3>
                <h6>Informações sobre o organizador.</h6>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form role="form" action="" method="post" enctype="multipart/form-data">
                <div class="card-body">
                  <div class="form-group">
                  <!-- <label for="cars">Choose a car:</label>
                  <select name="cars" id="cars">
                    <optgroup label="Swedish Cars">
                      <option value="volvo">Volvo</option>
                      <option value="saab">Saab</option>
                    </optgroup>
                    <optgroup label="German Cars">
                      <option value="mercedes">Mercedes</option>
                      <option value="audi">Audi</option>
                    </optgroup>
                  </select> -->
                  </div>
                  <div class="inline-block">
                    <div class="form-group">
                      <label for="exampleInputEmail1">Nome *</label>
                      <input style="width:100%;" type="text" maxlength="100" class="form-control" value="<?php echo $row['nome_organizador']?>" name="nome_organizador" id="nome_organizador" required>
                    </div>
                  </div>
                  <div class="inline-block">
                    <div class="form-group">
                      <label for="exampleInputEmail1">ID</label>
                      <input style="width:40px;" type="text" class="form-control" name="fk_eventos_organizador" id="fk_eventos_organizador" value="<?php echo $idorganizadorUser ?>" readonly required>
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Descrição do organizador (opcional)</label>
                    <input style="height:250px; width:100%" placeholder="Adicione aqui a descrição do organizador..." type="text" class="descricao_local" name="descricao_organizador" id="descricao_organizador" value="<?php echo $row['descricao_organizador']; ?>"></input>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <style>
        .content4 {
          display: flex;
          align-items: left;
          justify-content: left;
        }
      </style>
      <br>
        <section class="content3">
        <div class="container">
          <!-- left column -->
          <div class="col-lg">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">5 - Imagem do evento</h3>
                <h6>Insira a imagem de divulgação do evento.</h6>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form role="form" action="" method="post" enctype="multipart/form-data">
                <div class="card-body">
                  <div class="form-group">
                    <label for="exampleInputFile">Imagem de divulgação</label>
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text" id="inputGroupFileAddon01">Enviar</span>
                      </div>
                      <div class="custom-file">
                        <input type="file" name="foto" class="custom-file-input" id="inputGroupFile01"
                          aria-describedby="inputGroupFileAddon01">
                        <label class="custom-file-label" for="inputGroupFile01">Escolher arquivo...</label>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="card-footer">
              <button id="confirm_button" type="submit" name="button_publicar" class="btn btn-success btn-lg btn-block">Alterar Evento</button>
            </div>
        </section>
                 
                  <style>
                    #confirm_button {
                      float: right; 
                      padding: 10px 24px; 
                      border-radius: 12px;
                      transition-duration: 0.4s;
                      margin-bottom: 10px;
                    }

                    #confirm_button:hover {
                      background-color: #4CAF50; /* Green */
                      color: #2D1E41;
                    }
                  </style>
                </form>
                <?php
                  if(isset($_POST['button_publicar'])){
                    $nome_evento = $_POST['nome_evento'];
                    $data_inicio = $_POST['data_inicio'];
                    $hora_inicio = $_POST['hora_inicio'];
                    $data_termino = $_POST['data_termino'];
                    $hora_termino = $_POST['hora_termino'];
                    $descricao = $_POST['descricao'];
                    $nome_local = $_POST['nome_local'];
                    $cep = $_POST['cep'];
                    $rua = $_POST['rua'];
                    $bairro = $_POST['bairro'];
                    $numero = $_POST['numero'];
                    $complemento = $_POST['complemento'];
                    $cidade = $_POST['cidade'];
                    $estado = $_POST['estado'];
                    $nome_organizador = $_POST['nome_organizador'];
                    $descricao_organizador = $_POST['descricao_organizador'];
                    $fk_eventos_organizador	= $_POST['fk_eventos_organizador'];
                  //$senha = base64_encode($_POST['senha']);
                  //Verificar se existe imagem para fazer o upload
                  if(!empty($_FILES['foto']['name'])) {
                    $formatP = array("png", "jpg", "jpeg", "gif");
                    $extensao = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);

                    if (in_array($extensao, $formatP)) {
                      $pasta = "../img/";
                      $temporario = $_FILES['foto']['tmp_name'];
                      $novoNome = uniqid() . ".{$extensao}";

                      if (move_uploaded_file($temporario, $pasta . $novoNome)) {

                      } else {
                        $mensagem = "Erro, não foi possivel fazer o upload do arquivo!";
                      }
                    } else {
                      echo "Formato inválido";
                    }
                  }else{
                    $novoNome = $foto_user;
                  }

                  $update = "UPDATE eventos SET foto_evento=:foto_evento,
                  nome_evento=:nome_evento,
                  data_inicio=:data_inicio,
                  hora_inicio=:hora_inicio,
                  data_termino=:data_termino,
                  hora_termino=:hora_termino,
                  descricao=:descricao,
                  nome_local=:nome_local,
                  cep=:cep,
                  rua=:rua,
                  bairro=:bairro,
                  numero=:numero,
                  complemento=:complemento,
                  cidade=:cidade,
                  estado=:estado,
                  nome_organizador=:nome_organizador,
                  descricao_organizador=:descricao_organizador
                  WHERE fk_eventos_organizador=$idorganizadorUser";

                  try{
                    $result = $pdo->prepare($update);
                    $result->bindParam(':nome_evento',$nome_evento,PDO::PARAM_STR);
                    $result->bindParam(':foto_evento',$novoNome,PDO::PARAM_STR);
                    $result->bindParam(':data_inicio',$data_inicio,PDO::PARAM_STR);
                    $result->bindParam(':hora_inicio',$hora_inicio,PDO::PARAM_STR);
                    $result->bindParam(':data_termino',$data_termino,PDO::PARAM_STR);
                    $result->bindParam(':hora_termino',$hora_termino,PDO::PARAM_STR);
                    $result->bindParam(':descricao',$descricao,PDO::PARAM_STR);
                    $result->bindParam(':nome_local',$nome_local,PDO::PARAM_STR);
                    $result->bindParam(':cep',$cep,PDO::PARAM_STR);
                    $result->bindParam(':rua',$rua,PDO::PARAM_STR);
                    $result->bindParam(':bairro',$bairro,PDO::PARAM_STR);
                    $result->bindParam(':numero',$numero,PDO::PARAM_STR);
                    $result->bindParam(':complemento',$complemento,PDO::PARAM_STR);
                    $result->bindParam(':cidade',$cidade,PDO::PARAM_STR);
                    $result->bindParam(':estado',$estado,PDO::PARAM_STR);
                    $result->bindParam(':nome_organizador',$nome_organizador,PDO::PARAM_STR);
                    $result->bindParam(':descricao_organizador',$descricao_organizador,PDO::PARAM_STR);
                    $result->execute();
                    // alerte abaixo
                    $contar = $result->rowCount();
                    if($contar>0){
                      echo "<script>location.href=\"meusEventos.php\";alert('Perfil atualizado com sucesso!');</script>";
                    

                    }else{
                      echo "<script>location.href=\"meusEventos.php\";alert('Erro! Perfil não foi atualizado!');</script>";
                      // echo '<div class="alert alert-danger alert-dismissible">
                      //               <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                      //               <h5><i class="icon fas fa-check"></i> Erro !!!</h5>
                      //               Perfil não foi atualizar.
                      //             </div>';
                    }
                  }catch (PDOException $e){
                    echo "<strong>ERRO DE PDO= </strong>".$e->getMessage();
                  }

                }
                ?>
                  <!-- Aqui fica o php foto -->
              </div>
            </div>
          </div>
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
        <!-- /.content -->
    </div>
      <!-- /.content-wrapper -->
    <script type="text/javascript" src="../js/jquery-3.2.1.slim.min.js"></script>
    <script type="text/javascript" src="../js/popper.min.js"></script>
    <script type="text/javascript" src="../js/bootstrap.js"></script>
    <script type="text/javascript" src="../js/app.js"></script>
    <script type="text/javascript" src="../js/tela_cadastro.js"></script>
  </body>
</html>

<?php else: header("Location: ../login_convidado.php"); endif; ?>