<?php
  require '../verifica_organizador.php';
  if(isset($_SESSION['idUser']) && !empty($_SESSION['idUser'])):
?>

<!DOCTYPE html>
<html>
  <head>
    <title>TicketClick</title>
    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css">

    <link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="shortcut icon" sizes="250x100" href="../icons/icone-ticket.ico">

    <style>
        #checkbox {
        width:50%;
        float: right;
        position:absolute;
        top:132px;
        left:775px;
        height:350px;
        }
    </style>

        <script>
            function goBack() {
                window.history.back()
            }
		</script>
    
  </head>
  <body>
    <header class="menu-nav">
      <nav class="container navbar navbar-expand-md navbar-dark">
        <a href="../index_organizador.php" class="navbar-brand">
          <img src="../img/ticketclick.svg" alt="TicketClick">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Abrir Navegação">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto">
          <a style="color: grey;" class="nav-link" href="">(Organizador)</a>
            <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" style="float: right" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo $nomeUser; ?></a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="perfil/perfil_organizador.php">Minha Conta</a>
              <a class="dropdown-item" href="organizador/meusEventos.php">Meus Eventos</a>
              <a class="dropdown-item" href="organizador/operador.php">Operador</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="../sair.php">Sair</a>
            </div>
            </li>
          </ul>
        </div>  
      </nav>
    </header>
    <a class="btn-menu btn ml-md-2" href="#organizador" onclick="goBack()">Voltar</a>
    <?php include('../config.php'); ?>
    <center>
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Permissões para o operador</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body p-0">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th style="width: 10000px">Atividades</th>
                            <th style="width: 40px">Permissões</th>
                        </tr>
                    </thead>
                    <tbody>             
                    <tr>
                        <td><strong>Criar Evento<strong></td>
                        <td>
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" id="flexSwitchCheckDefault">
                                <label class="form-check-label" for="flexSwitchCheckDefault"></label>
                            </div>
                        </td>
                    </tr>                
                    </tbody>
                    <tbody>             
                    <tr>
                        <td><strong>Alterar Evento</strong></td>
                        <td>
                        <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" id="flexSwitchCheckDefault">
                        <label class="form-check-label" for="flexSwitchCheckDefault"></label>
                    </div>
                        </td>
                    </tr>                
                    </tbody>
                    <tbody>             
                    <tr>
                        <td><strong>Deletar Evento</strong></td>
                        <td>
                        <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" id="flexSwitchCheckDefault">
                        <label class="form-check-label" for="flexSwitchCheckDefault"></label>
                    </div>
                        </td>
                    </tr>                
                    </tbody>
                    <tbody>             
                    <tr>
                        <td><strong>Leitura do relatório de convidados</strong></td>
                        <td>
                        <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" id="flexSwitchCheckDefault">
                        <label class="form-check-label" for="flexSwitchCheckDefault"></label>
                    </div>
                    </tr>                
                    </tbody>
                    <tbody>             
                    <tr>
                        <td><strong>Validar Evento por Código</strong></td>
                        <td>
                        <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" id="flexSwitchCheckDefault">
                        <label class="form-check-label" for="flexSwitchCheckDefault"></label>
                    </div>
                        </td>
                    </tr>                
                    </tbody>
                    <tbody>             
                    <tr>
                        <td><strong>Validar Evento por QR Code</strong></td>
                        <td>
                        <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" id="flexSwitchCheckDefault">
                        <label class="form-check-label" for="flexSwitchCheckDefault"></label>
                    </div>
                        </td>
                    </tr>                
                    </tbody>
                </table>
                </div>
                <!-- /.card-body -->
                </div>
                <!-- /.card -->
                <a href="../index_organizador.php" style="float:right;margin-bottom:10px;" class="btn btn-outline-success btn-lg btn-block">Salvar</a>
                </div></center>

                    </div>
                <!--/.col (right) -->
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
  </body>
</html>

<?php else: header("Location: ../login_organizador.php"); endif; ?>