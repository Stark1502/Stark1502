<?php
include_once("../config.php");

    function verifica_codigo($conexao) {
        $codigo = addslashes($_POST['codigo']);
        $sql = $conexao->prepare("SELECT * FROM ingressos_gratuito WHERE codigo = ?");
        $sql->bind_param("s", $codigo);
        $sql->execute();
        $get = $sql->get_result();
        $total = $get->num_rows;

        if($total > 0) {
            $dados = $get->fetch_assoc();
            update_dados_valida($conexao, $codigo);
		}else{
            echo "<br><div class='alert alert-danger w-50 p-3 offset-md-3'>Código incorreto, favor verificar!</div>";
        }
    }

    function update_dados_valida($conexao, $codigo) {
        $validado = 'Sim';
        $sql = $conexao->prepare("UPDATE ingressos_gratuito SET validado = ? WHERE codigo = ?");
        $sql->bind_param("ss", $validado, $codigo);
        $sql->execute();

        if($sql->affected_rows > 0) {
            echo "<br><div class='alert alert-success w-50 p-3 offset-md-3'>Seu ingresso foi validado com sucesso!</div>";
		}else{
            echo "<br><div class='alert alert-danger w-50 p-3 offset-md-3'>O ingresso já foi validado!</div>";
        }
    }

?>