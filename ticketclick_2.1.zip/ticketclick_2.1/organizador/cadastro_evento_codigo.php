<?php

    include_once('../config.php');

    $nome_evento = $_POST['nome_evento'];
    $data_inicio = $_POST['data_inicio'];
    $hora_inicio = $_POST['hora_inicio'];
    $data_termino = $_POST['data_termino'];
    $hora_termino = $_POST['hora_termino'];
    $descricao = $_POST['descricao'];

    $nome_local = $_POST['nome_local'];
    $cep = $_POST['cep'];
    $endereco = $_POST['endereco'];
    $bairro = $_POST['bairro'];
    $numero = $_POST['numero'];
    $complemento = $_POST['complemento'];
    $cidade = $_POST['cidade'];
    $estado = $_POST['estado'];

    $tipo_ingresso_gratuito = $_POST['tipo_ingresso_gratuito'];
    $quantidade_gratuito = $_POST['quantidade_gratuito'];
    $preco_gratuito = "Gratuito";
    $data_inicio_gratuito = $_POST['data_inicio_gratuito'];
    $hora_inicio_gratuito = $_POST['hora_inicio_gratuito'];
    $data_termino_gratuito = $_POST['data_termino_gratuito'];
    $hora_termino_gratuito = $_POST['hora_termino_gratuito'];

    $tipo_ingresso_pago = $_POST['tipo_ingresso_pago'];
    $quantidade_pago = $_POST['quantidade_pago'];
    $preco_pago = $_POST['preco_pago'];
    $data_inicio_pago = $_POST['data_inicio_pago'];
    $hora_inicio_pago = $_POST['hora_inicio_pago'];
    $data_termino_pago = $_POST['data_termino_pago'];
    $hora_termino_pago = $_POST['hora_termino_pago'];

    $nome_organizador = $_POST['nome_organizador'];
    $descricao_organizador = $_POST['descricao_organizador'];
    $fk_eventos_organizador	= $_POST['fk_eventos_organizador'];

    $result = mysqli_query($conexao, "INSERT INTO eventos
    (
    nome_evento,
    data_inicio,
    hora_inicio,
    data_termino,
    hora_termino,
    descricao,
    nome_local,
    cep,
    rua,
    bairro,
    numero,
    complemento,
    cidade,
    estado,
    tipo_ingresso_gratuito,
    quantidade_gratuito,
    preco_gratuito,
    data_inicio_gratuito,
    hora_inicio_gratuito,
    data_termino_gratuito,
    hora_termino_gratuito,
    tipo_ingresso_pago,
    quantidade_pago,
    preco_pago,
    data_inicio_pago,
    hora_inicio_pago,
    data_termino_pago,
    hora_termino_pago,
    nome_organizador,
    descricao_organizador,
    fk_eventos_organizador
    ) 

    VALUES ('$nome_evento',
    '$data_inicio',
    '$hora_inicio',
    '$data_termino',
    '$hora_termino',
    '$descricao',
    '$nome_local', 
    '$cep', 
    '$endereco',
    '$bairro',
    '$numero',
    '$complemento',
    '$cidade',
    '$estado', 
    '$tipo_ingresso_gratuito',
    '$quantidade_gratuito',
    '$preco_gratuito',
    '$data_inicio_gratuito',
    '$hora_inicio_gratuito',
    '$data_termino_gratuito',
    '$hora_termino_gratuito',
    '$tipo_ingresso_pago', 
    '$quantidade_pago',
    '$preco_pago', 
    '$data_inicio_pago',
    '$hora_inicio_pago',
    '$data_termino_pago',
    '$hora_termino_pago',
    '$nome_organizador', 
    '$descricao_organizador', 
    '$fk_eventos_organizador')");

    echo "<script>alert('Evento publicado com sucesso!');location.href=\"meusEventos.php\";</script>";

?>