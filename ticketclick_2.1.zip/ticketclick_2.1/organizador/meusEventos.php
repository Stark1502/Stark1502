<?php
  require '../verifica_organizador.php';
  if(isset($_SESSION['idUser']) && !empty($_SESSION['idUser'])):
?>

<!DOCTYPE html>
<html>
  <head>
    <title>TicketClick - Meus eventos</title>
    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css">

    <link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="shortcut icon" sizes="250x100" href="../icons/icone-ticket.ico">
    
  </head>
  <body>
    <header class="menu-nav">
      <nav class="container navbar navbar-expand-md navbar-dark">
        <a href="../index_organizador.php" class="navbar-brand">
          <img src="../img/ticketclick.svg" alt="TicketClick">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Abrir Navegação">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto">
          <a style="color: grey;" class="nav-link">(Organizador)</a>
            <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" style="float: right" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo $nomeUser; ?></a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="perfil/perfil_organizador.php">Minha Conta</a>
              <a class="dropdown-item" href="organizador/meusEventos.php">Meus Eventos</a>
              <a class="dropdown-item" href="">Promoções</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="../sair.php">Sair</a>
            </div>
            </li>
          </ul>
        </div>  
      </nav>
    </header>
    <a class="btn-menu btn ml-md-2" href="../index_organizador.php">Voltar</a>
      <div class="row">
        <div class="col-sm-6 offset-md-3">
          <form method="POST">
            <h2>MEUS EVENTOS</h2>
            <hr>
            <br>
            <div class="inline-block">
              <h5>Eventos: <?php

                include_once('../config.php');

                // $result = mysqli_query($conexao, "SELECT DISTINCT SUM(ID_evento) as Soma FROM eventos INNER JOIN cadastro_organizador WHERE nome = 'Pedro Henrique Pereira de Souza'");
                // $result = mysqli_query($conexao, "SELECT DISTINCT COUNT(ID_evento) as Soma FROM eventos A INNER JOIN cadastro_organizador B ON A.nome_organizador = B.nome;");
                $result = mysqli_query($conexao, "SELECT COUNT(ID_evento) as Soma FROM eventos WHERE fk_eventos_organizador = $idorganizadorUser");
                $row = $result->fetch_assoc();
                echo $row['Soma'];
              ?>.</h5>
            </div>
            <div class="inline-block">
              <a id="imagem_evento" class="btn-menu btn ml-md-2" href="cadastro_evento.php">Criar evento</a>
              <style>
                #imagem_evento {
                  position:absolute;
                  top:110px;
                  left:300px;
                  height:35px;
                }

                .imagem_evento {
                  width:100%;
                }
              </style>
            </div>
          </form> 
        </div>
      </div>
      <style>
        .inline-block {
          display: inline-block;
          margin-bottom: 40px;
        }
      </style>
      <style>
        .imagem_evento {
          width:100%;
        }
      </style>
      <div class="row">
                <style>
                  .inline-block {
                    display: inline-block;
                    margin-top: 40px;
                  }
              </style>
            <br>
              <?php

                include_once('../config.php');

                $result_eventos = "SELECT * FROM eventos WHERE fk_eventos_organizador = '$idorganizadorUser'";
                $resultado_eventos = mysqli_query($conexao, $result_eventos);

                ?>
              <div class="row">
              <div class="col-sm-6 offset-md-3">
              <?php while($row_usuario = mysqli_fetch_assoc($resultado_eventos)) { ?>
                <form method="POST">
                  <div class="col-md">
                    <div class="card">
                      <div class="card-header">
                        <h3 class="card-title"></h3>
                        <h3 class="card-title"><center><?php echo $row_usuario['nome_evento'];?></h3></center>
                      </div>
                      <!-- /.card-header -->
                      <div class="card-body p-1" style="text-align: center; margin-bottom: 10px; width: 100%">
                        <center><img src="../img/<?php echo $row_usuario['foto_evento'];?>" alt="Imagem do evento..." style="width: 250px; border-radius: 6px; margin-top: 20px"></center>
                        <br></a>
                        <br>
                        <strong><p style="color: #2D1E41" class="card-text"><i class="fas fa-calendar me-1"></i><?php echo $row_usuario['data_inicio'];?> > <?php echo $row_usuario['data_termino'];?></p>
                        <p><i class="fas fa-bell me-1"></i><?php echo $row_usuario['hora_inicio'];?> : <?php echo $row_usuario['hora_termino'];?></p></strong>
                        <br>

                        <h4 style="text-align: center"><?php echo $row_usuario['descricao'];?></h4>
                        <h6 style="text-align: center"><?php echo $row_usuario['rua']?>, <?php echo $row_usuario['bairro']?>, <?php echo $row_usuario['numero']?>, <?php echo $row_usuario['cidade']?>, <?php echo $row_usuario['estado']?>.</h6>
                        <style>
                          .inline-block {
                            display: inline-block;
                            margin-top: 20px;
                          }
                      </style>
                        <div class="inline-block">
                          <a class="btn btn-warning" href="editar_evento.php">Editar evento</a>
                        </div>
                        <?php

                        if(isset($_POST["button_deletar"])) {
                          
                          $result = mysqli_query($conexao, "SELECT * FROM eventos");
                          $row = $result->fetch_assoc();
                          $soma_delete = $row['ID_evento'];
                          $result_delete = mysqli_query($conexao, "DELETE FROM eventos WHERE ID_evento = $soma_delete");
                          echo "<script>alert('Evento deletado com sucesso!');location.href=\"meusEventos.php\";</script>";
                        }else{
                          echo "<script>alert('Erro!);location.href=\"meusEventos.php\";</script>";
                        }
                        ?>

                        <div class="inline-block">
                          <button type="button_deletar" name="button_deletar" class="btn btn-danger">Deletar Evento</button>
                        </div>

                        <div class="inline-block">
                          <a class="btn btn-primary" href="relatorio_convidados.php">Relatório de convidados</a>
                        </div>
                        <style>
                          .inline-block {
                            display: inline-block;
                            margin-top: 20px;
                          }
                        </style>
                      </div>
                      <br>
                      <!-- /.card-body -->
                    </div>
                    <br>
                        </div>
                    <?php 
                    } 
                    ?>
                    <!-- /.card -->
                  </div>
                  <br>
                </form>
              </div>
            </div>
    </body>
    <script type="text/javascript" src="../js/meusEventos.js"></script>
    <script>
		function goBack() {
			window.history.back()
		}
		</script>
</html>

<?php else: header("Location: ../login_organizador.php"); endif; ?>