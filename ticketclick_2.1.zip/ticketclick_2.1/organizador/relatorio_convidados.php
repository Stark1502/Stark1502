<?php
  require '../verifica_organizador.php';
  if(isset($_SESSION['idUser']) && !empty($_SESSION['idUser'])):
?>

<!DOCTYPE html>
<html>
  <head>
    <title>TicketClick - Meus eventos</title>
    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css">

    <link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="shortcut icon" sizes="250x100" href="../icons/icone-ticket.ico">

    <script>
            function goBack() {
                window.history.back()
            }
		</script>
    
  </head>
  <body>
    <header class="menu-nav">
      <nav class="container navbar navbar-expand-md navbar-dark">
        <a href="../index_organizador.php" class="navbar-brand">
          <img src="../img/ticketclick.svg" alt="TicketClick">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Abrir Navegação">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto">
          <a style="color: grey;" class="nav-link" href="">(Organizador)</a>
            <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" style="float: right" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo $nomeUser; ?></a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="perfil/perfil_organizador.php">Minha Conta</a>
              <a class="dropdown-item" href="organizador/meusEventos.php">Meus Eventos</a>
              <a class="dropdown-item" href="">Promoções</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="../sair.php">Sair</a>
            </div>
            </li>
          </ul>
        </div>  
      </nav>
    </header>
    <div class="container">
    <a class="btn-menu btn ml-md-2" href="#organizador" onclick="goBack()">Voltar</a>
    <?php include('../config.php'); ?>

            <center><div class="col">
              <br>
            <div class="card">
              <div class="card-header">
                <h3 style="margin-top:20px;" class="card-title">Relatório de convidados</h3>
                <input type="text" id="txtBusca" onkeyup="pesquisar()" placeholder="Buscar..."/>
              </div>
              <!-- /.card-header -->
              <div class="card-body p-0">
                <table class="table table-striped">
                  <thead>
                    <tr>
                      <th>Nome</th>
                      <th>E-mail</th>
                      <th>Validado</th>
                      <th>Ações</th>
                    </tr>
                  </thead>
                  <tbody id="menu">
                    <?php

                    $select = "SELECT * FROM ingressos_gratuito WHERE fk_ingressos_gratuito_eventos = 35";
                    //   $select = "SELECT ID_evento FROM eventos A INNER JOIN ingressos_gratuito B ON a.ID_evento = b.ID_evento ORDER BY ID_ingresso_gratuito LIMIT 6";
                      $resultado_eventos = mysqli_query($conexao, $select);
                      
                    ?>
                                      
                    <tr>
                    <?php while($row_usuario = mysqli_fetch_assoc($resultado_eventos)) { ?>
                      <td>
                        <?php echo $row_usuario['nome_ingresso'];?> <?php echo $row_usuario['sobrenome_ingresso'];?>
                      </td>
                      <td>
                        <?php echo $row_usuario['email_ingresso'];?>
                      </td>
                      <td>
                        <?php echo $row_usuario['validado'];?>
                      </td>
                      <td>
                      <div class="btn-group">
                        <a href="valida_codigo.php" class="btn btn-success" title="Validar convidado"><i class="fas fa-user-edit"></i></button>
                        <a href="conteudo/del-contato.php?idDel=<?php echo $row_usuario['nome_ingresso'];?>" onclick="return confirm('Deseja remover o convidado')" class="btn btn-danger" title="Remover convidado"><i class="fas fa-user-times"></i></a>
                      </div>
                      </td>
                    </tr>
                    <?php
                      }
                    ?>                 
                  </tbody>
                  <?php
                  $count_validado = mysqli_query($conexao, "SELECT COUNT(fk_ingressos_gratuito_convidado) as Soma FROM ingressos_gratuito WHERE fk_ingressos_gratuito_eventos = 35 AND validado = 'Sim'");
                  $row_validado = $count_validado->fetch_assoc();

                  $count_evento = mysqli_query($conexao, "SELECT COUNT(fk_ingressos_gratuito_eventos) as Soma FROM ingressos_gratuito WHERE fk_ingressos_gratuito_eventos = 35");
                  $row_evento = $count_evento->fetch_assoc();
                  ?>
                  <tfoot>
                  <tr>
                      <th scope="row">Totais</th>
                      <td></td>
                      <td><strong><?php echo $row_validado['Soma']; ?></strong></td>
                      <td><strong><?php echo $row_evento['Soma']; ?></strong></td>
                  </tr>
                  </tfoot>
                </table>
              </div>
              <!-- /.card-body -->
            </div></center>
            <!-- /.card -->
            </div>

          </div>
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
      </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  </body>
</html>
<script type="text/javascript" src="../js/pesquisar2.js"></script>

<?php else: header("Location: ../login_organizador.php"); endif; ?>