<!DOCTYPE html>
<html lang="en">
  <head>
  
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" sizes="250x100" href="../icons/Tticket.png">
    <link rel="stylesheet" href="/ticketclick_atual/CSSeventos/V.css">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css">
    
    <link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="/ticketclick_atual/login.php">
    <link rel="stylesheet" href="/ticketclick_atual/index.php">
    <link rel="stylesheet" href="/ticketclick_atual/cadastro_convidado.php">
    <link rel="stylesheet" href="/ticketclick_atual/CSSeventos/rockinrio.css">

    <Title>TicketClick - Celeiro Resende </Title>
 
  

  </head>
  <body>
    <header class="menu-nav">
        <nav class="container navbar navbar-expand-md navbar-dark">
          <a href="../index.php" class="navbar-brand">
            <img src="../img/ticketclick.svg" alt="TicketClick">
          </a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Abrir Navegação">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item">
                <a class="nav-link" href="../login_convidado.php">Login</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="../cadastro_convidado.php">Inscrever-se</a>
              </li>
              <li class="nav-item">
                <a class="btn-menu btn ml-md-2" href="../cadastro_organizador.php">Seja um organizador</a>
              </li>
            </ul>
          </div>  
        </nav>
      </header>         
      <!--<section>
          <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
              <div class="carousel-item active">
            
              </div>
            </div>
          </div>
      </section> -->


       <div class="bg-header">
             <center> <img src="../img/celeiro1.jpg"  width= 800px height = 400px alt=""></center>  
                
                </div>
  
 
    
    <hr>
    <h1 class="" align="center">Celeiro Resende</h1> 
    <hr>
    <div class="container">
      <div align="center">
        <h2 align="center"><u>Data do Evento</u></h2>
        <br>
        <p class="card-text"><i class="fas fa-calendar me-1"></i>15/10/2022 </p>
        <p class="card-text"><i class="fas fa-map me-1"></i>17/10/2022</p>
      </div>
      <div align="center">
              <hr>
              <h2><u>Descrição</u></h2>
              <br>
            </div>
            <div align="center">
              <p>
                

A maior e mais tradicional Casa de Shows e Eventos da cidade de Resende, funcionamento ao os finais de semana.
              </p>
              <p> 
  Diversas atrações de fuck, rock e entre outros ...
  
              </p>  
  
            </div>
            <div align="center">
                    <hr></hr>
                    <div style="float: center"><h2><u>Mapa do Evento</u></h2>
                      <br>
                      <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3686.9086348826786!2d-44.46259328557159!3d-22.47006742808105!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x9e7fdb70c6dcc5%3A0x6bb4c28b6fcdaff9!2sCeleiro!5e0!3m2!1spt-BR!2sbr!4v1665695309447!5m2!1spt-BR!2sbr" width="500" height="250" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            <p class="ui-pdp-family--REGULAR ui-vip-payment_methods__title"></p>
            <div class="ui-pdp-payment-icon">
              <div class="ui-pdp-payment-icon__container">
                <div align="center">
                  <hr align="center">
                    <h2 class="ui-box-component__title"><u>Meios de Pagamentos</u></h2> 
                </div>
              </div>
            </div>
            <br>
              <div align="Center">
  
              <h4 class="ui-pdp-family--REGULAR ui-vip-payment_methods__title">Cartões de crédito</h4>
                <div class="ui-pdp-payment-icon">
                  <div class="ui-pdp-payment-icon__container">
                    <div class="ui-pdp-payment-icon__size">
                      <img decoding="async" src="https://http2.mlstatic.com/storage/logos-api-admin/a5f047d0-9be0-11ec-aad4-c3381f368aaf-m.svg" class="ui-pdp-image ui-pdp-payment-icon"  alt="Visa">
                    </div>
                  </div>
                  <div class="ui-pdp-payment-icon__container">
                    <div class="ui-pdp-payment-icon__size">
                      <img decoding="async" src="https://http2.mlstatic.com/storage/logos-api-admin/aa2b8f70-5c85-11ec-ae75-df2bef173be2-m.svg" class="ui-pdp-image ui-pdp-payment-icon" alt="Mastercard">
                    </div>
                  </div>
                  <div class="ui-pdp-payment-icon__container">
                    <div class="ui-pdp-payment-icon__size">
                      <img decoding="async" src="https://http2.mlstatic.com/storage/logos-api-admin/ddf23a60-f3bd-11eb-a186-1134488bf456-m.svg" class="ui-pdp-image ui-pdp-payment-icon" alt="Hipercard">
                    </div>
                  </div>
                  <div class="ui-pdp-payment-icon__container">
                    <div class="ui-pdp-payment-icon__size">
                      <img decoding="async" src="https://http2.mlstatic.com/storage/logos-api-admin/ed8d6fd0-f3bd-11eb-9984-b7076edb0bb7-m.svg" class="ui-pdp-image ui-pdp-payment-icon" alt="Elo">
                    </div>
                  </div>
                </div>
                <br>
  
              <h4 class="ui-pdp-family--REGULAR ui-vip-payment_methods__title">Cartões de débito</h4>
              <div class="ui-pdp-payment-icon">
                <div class="ui-pdp-payment-icon__container">
                  <div class="ui-pdp-payment-icon__size">
                    <img decoding="async" src="https://http2.mlstatic.com/storage/logos-api-admin/d2407420-f3bd-11eb-8e0d-6f4af49bf82e-m.svg" class="ui-pdp-image ui-pdp-payment-icon" alt="Caixa">
                  </div>
                </div>
              </div>
              <br>
            
              <h4 class="ui-pdp-family--REGULAR ui-vip-payment_methods__title">Boleto bancário</h4>
              <div class="ui-pdp-payment-icon">
                <div class="ui-pdp-payment-icon__container">
                  <div class="ui-pdp-payment-icon__size">
                    <img decoding="async" src="https://http2.mlstatic.com/storage/logos-api-admin/00174300-571e-11e8-8364-bff51f08d440-m.svg" class="ui-pdp-image ui-pdp-payment-icon" alt="Boleto">
                  </div>
                </div>
              </div>
              <br>
              <!--  <div align="center"> 
                  <a href="" class="btn btn-success btn-lg btn-block">Comprar Ingresso</a>     
                </div> -->
          





<!-- Botão para acionar modal -->
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#ModalLongoExemplo">
Comprar Ingresso
</button>

<!-- Modal -->
<div class="modal fade" id="ModalLongoExemplo" tabindex="-1" role="dialog" aria-labelledby="TituloModalLongoExemplo" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="TituloModalLongoExemplo">  TicketClick</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      


        
  <p class="help" style="">
  </p>


    <div class="merchant">
      <img id="crickets"  width= 70px height = 70px  src="../img/bilhete.png"    /> <P></P>
   
      <h5 class="center-align">TicketClick - Pagamento</h5>
      <p>Outubro 2022</p>
    </div>

    <div class="invoice">
      <table class="highlight">
        <thead>
          <tr>
            <th>QTD</th>
            <th></th>
            <th > ITEM  </th>
            <th class="right-align"> (Preço)</th>
          </tr>
        </thead>
        <tbody>
          <tr>
          <th></th>  <td>-1</td>
            <td>Celeiro </td>
            <td class="right-align">   R$ 30.00</td>
          </tr>
         <!--  <tr>
         <th></th> <td>-2</td>
            <td>Rock in Rio</td>
            <td class="right-align">   R$800.00</td>
          </tr>-->
          <tr>
          <th></th>  <td>-2</td>
            <td class="right-align">Taxa</td>
            <td class="right-align">$0.00</td>

          
          </tr>

          <tr>
            <td></td>
            <br>
          


            <td class="left-align bold"><P></P> Total -</td>
            <td class="left-align bold"><P></P> R$ 30,00</td>
          </tr>
        </tbody>
      </table>
    

    <!--<h5>Informação de Pagamento !!</h5> -->


 <br>

 <br>


      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
        <script src="https://www.mercadopago.com.br/integrations/v1/web-payment-checkout.js"
data-preference-id="309358353-93df54ce-6baa-4d4a-8615-f31270e768cb" data-source="button">
</script>
      </div>
    </div>
  </div>
</div>




            <br>
          </div>
        </div> 
      </div>
    </div>
  </div>




















    <style>
    div.box{
      width: 1300px;
      height: 35rem;
    /*display: inline-block;*/
    }
  
    div. ui-pdp-family--REGULAR ui-vip-payment_methods__title {
      display: inline-block;
  
    }
  
  
    h9{
  
    font-size: 16px;
    font-weight: bold;
  
    margin: 10px 50px 20px;
    }
  
    p{
      margin: 10px 20px 20px;
  
  
    }
  
    section{
  
    
      margin: 10px 10px 20px;
  
    }
  
    </style>
          </div>
        </div>
      </div>
    </div>
  </div>
            
    <!-- Footer -->
    <footer class="text-center text-lg-start bg-dark text-muted">
      <!-- Section: Social media -->
      <section
        class="d-flex justify-content-center justify-content-lg-between p-4 border-bottom"
      >
        <!-- Left -->
        <div class="me-5 d-none text-white d-lg-block">
          <span>Saiba mais sobre nós:</span>
        </div>
        <!-- Left -->
  
        <!-- Right -->
        <div>
          <a href="" class="me-4 text-reset">
            <i class="fab fa-facebook-f"></i>
          </a>
          <a href="" class="me-4 text-reset">
            <i class="fab fa-twitter"></i>
          </a>
          <a href="" class="me-4 text-reset">
            <i class="fab fa-google"></i>
          </a>
          <a href="" class="me-4 text-reset">
            <i class="fab fa-instagram"></i>
          </a>
          <a href="" class="me-4 text-reset">
            <i class="fab fa-linkedin"></i>
          </a>
          <a href="https://github.com/pedr4souz4/ticketclick" class="me-4 text-reset">
            <i class="fab fa-github"></i>
          </a>
        </div> 
        <!-- Right -->
      </section>
      <!-- Section: Social media -->
  
      <!-- Section: Links  -->
      <section class="">
        <div class="container text-md-start mt-5">
          <!-- Grid row -->
          <div class="row mt-3">
            <!-- Grid column -->
            <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">
              <!-- Content -->
              <h6 class="text-uppercase text-white fw-bold mb-4">
              <!-- <img src="icons/diamond.svg"></img> TicketClick -->
              <i class="fas fa-gem me-"></i> TicketClick
              </h6>
              <p class="text-white">
              O <strong>TicketClick</strong> é um site em desenvolvimento que tem a finalidade 
              de fazer um sistema de controle de acesso em eventos gerais, para inutilizar as listas de presença e ingressos em papel. 
              A validação do ingresso será feita tanto pelo celular via QR Code ou manual pelo site.
              </p>
            </div>
            <!-- Grid column -->
  
            <!-- Grid column -->
            <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
              <!-- Links -->
              <h6 class="text-uppercase text-white fw-bold mb-4">
                Contato
              </h6>
              <p class="text-white"><i class="fas fa-home text-white me-3"></i> Resende, RJ</p>
              <p class="text-white">
              <i class="fas fa-envelope me-3"></i>
                ticketclick@gmail.com
              </p>
              <p class="text-white"><i class="fas fa-phone me-3"></i> + 24 999 99 99</p>
              <p class="text-white"><i class="fas fa-envelope-open me-3"></i><a href="contato.php">Contate-nos</a></p>
            </div>
            <!-- Grid column -->
          </div>
          <!-- Grid row -->
        </div>
      </section>
      <!-- Section: Links  -->
  
      <!-- Copyright -->
      <div class="text-center text-white p-4" style="background-color: rgba(0, 0, 0, 0.05);">
        © 2022 Copyright:
        <a class="text-reset fw-bold" href="http://ticketclick.ml">ticketclick.ml</a>
      </div>
      <!-- Copyright -->
    </footer>
  <!-- Footer -->
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
  </html>
  
  