<?php

  include_once('../config.php');

  $nome_ingresso = $_POST['nome_ingresso'];
  $sobrenome_ingresso = $_POST['sobrenome_ingresso'];
  $email_ingresso = $_POST['email_ingresso'];
  $email_confirmacao = $_POST['email_confirmacao'];
  $fk_ingressos_gratuito_eventos = $_POST['fk_ingressos_gratuito_eventos'];
  $fk_ingressos_gratuito_convidado = $_POST['fk_ingressos_gratuito_convidado'];
  $validado = "Não";
  $codigo = substr(uniqid(rand()), 0, 5);
  // Saida: 43395

  $result = mysqli_query($conexao, "INSERT INTO ingressos_gratuito
  (
  nome_ingresso,
  sobrenome_ingresso,
  email_ingresso,
  email_confirmacao,
  fk_ingressos_gratuito_eventos,
  fk_ingressos_gratuito_convidado,
  validado,
  codigo
  )

  VALUES ('$nome_ingresso',
  '$sobrenome_ingresso',
  '$email_ingresso',
  '$email_confirmacao',
  '$fk_ingressos_gratuito_eventos',
  '$fk_ingressos_gratuito_convidado',
  '$validado',
  '$codigo')");

date_default_timezone_set('America/Sao_Paulo');

require_once('../PHPMailer.php');
require_once('../SMTP.php');
require_once('../Exception.php');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

$result_eventos = "SELECT * FROM eventos WHERE ID_evento = 35";
$resultado_eventos = mysqli_query($conexao, $result_eventos);
$row_usuario = mysqli_fetch_assoc($resultado_eventos);

$nome_evento = $row_usuario['nome_evento'];
$nome_organizador = $row_usuario['nome_organizador'];
$data_inicio = $row_usuario['data_inicio'];
$hora_inicio = $row_usuario['hora_inicio'];
$data_termino = $row_usuario['data_termino'];
$hora_termino = $row_usuario['hora_termino'];

$nome_ingresso = isset($_POST['nome_ingresso']) ? $_POST['nome_ingresso'] : 'Não informado';
$sobrenome_ingresso = isset($_POST['sobrenome_ingresso']) ? $_POST['sobrenome_ingresso'] : 'Não informado';
$email_ingresso = isset($_POST['email_ingresso']) ? $_POST['email_ingresso'] : 'Não informado';
$email_confirmacao = isset($_POST['email_confirmacao']) ? $_POST['email_confirmacao'] : 'Não informado';
$fk_ingressos_gratuito_eventos = isset($_POST['fk_ingressos_gratuito_eventos']) ? $_POST['fk_ingressos_gratuito_eventos'] : 'Não informado';
$fk_ingressos_gratuito_convidado = isset($_POST['fk_ingressos_gratuito_convidado']) ? $_POST['fk_ingressos_gratuito_convidado'] : 'Não informado';
$data = date('d/m/Y H:i:s');

if($email_ingresso) {
	$destinatario = $email_ingresso;

	$subject = "Seu ingresso para o evento: {$nome_evento}";
	$headers = "MIME-Version: 1.0" . "\r\n";
	$headers .= "From: TicketClick <ticketclick0@gmail.com>" . "\r\n";
	$headers .= "Content-Type: text/html; charset=UTF-8\r\n";
	$message = "<html><head>";
	$message .= "
	<body style='margin: 0; padding: 0;'>
	<table align='center' border='1' cellpadding='0' cellspacing='0' width='600'>
	 <tr>
	 <td align='center' bgcolor='#2D1E41' style='padding: 30px 0 30px 0;'>
	 <img src='../img/ticketclick.svg' alt='Criando Mágica de E-mail' width='300' height='210' style='display: block;' />
	</td>
	 </tr>
	 <tr>
	 <td bgcolor='#ffffff' style='padding: 40px 30px 40px 30px;'>
	 <table border='1' cellpadding='0' cellspacing='0' width='100%''>
	<table border='1' cellpadding='0' cellspacing='0' width='100%'>
	 <tr>
	  <td>
		<center><h1 style='font-family:Gill Sans Extrabold, sans-serif;'>Seu ingresso já está disponível!</h1></center>
	  </td>
	 </tr>
	 <tr>
	  <td style='padding: 20px 0 30px 0;font-family:Gill Sans Extrabold, sans-serif;font-size:20px;'>
	   Código: <strong>{$codigo}</strong><br>
	   <p>Evento: <strong>{$nome_evento}</strong></p> 
	   <br>Organizador: <strong>{$nome_organizador}</strong>
	   <br><i class='fas fa-calendar me-1'></i>Começa: <strong>{$data_inicio} - {$hora_inicio}</strong> 
	   <br>Termina: <strong>{$data_termino} - {$hora_termino}</strong>
	   <br><br> <a href='ticketclick.tk/convidado/meusIngressos.php' class='btn btn-primary' type='text'>Acessar ingresso</a> 
	  </td>
	 </tr>
	</table>
	 </tr>
	 <tr>
	<td bgcolor='#2D1E41' style='padding: 30px 30px 30px 30px;'>
	<table border='1' cellpadding='0' cellspacing='0' width='100%'>
	 <tr>
	 <td 'width='80%' style='color:white;font-family:Gill Sans Extrabold, sans-serif;'>
	 &reg; Dúvidas? Se sim, nos <a href='ticketclick.tk/convidado/meusIngressos.php' class='btn btn-primary' type='text'>Acessar ingresso</a> <br/>
	 Acesse nossas redes sociais:
	</td>
	<td align='right'>
	 <table border='0' cellpadding='0' cellspacing='0'>
	  <tr>
	   <td>
		<a href='https://github.com/pedr4souz4/ticketclick/'>
		 <img src='https://cdn-icons-png.flaticon.com/512/25/25231.png' alt='GitHub' width='38' height='38' style='display: block;' border='0' />
		</a>
	   </td>
	   <td style='font-size: 0; line-height: 0;' width='20'>&nbsp;</td>
	   <td>
		<a href=''>
		 <img src='https://upload.wikimedia.org/wikipedia/commons/thumb/5/51/Facebook_f_logo_%282019%29.svg/2048px-Facebook_f_logo_%282019%29.svg.png' alt='Facebook' width='38' height='38' style='display: block;' border='0' />
		</a>
	   </td>
	  </tr>
	 </table>
	</td>
	 </tr>
	</table>
	</td>
	 </tr>
	</table>
	";

	$message .="</head></html>";

	if(mail($destinatario, $subject, $message, $headers)){
		echo "<script>location.href=\"../convidado/meusIngressos.php\";alert('Ingresso adquirido com sucesso!')</script>";
	}else{
		echo "<script>location.href=\"../index_convidado.php\";alert('Falha ao adquirir o ingresso!')</script>";
	}
}

?>