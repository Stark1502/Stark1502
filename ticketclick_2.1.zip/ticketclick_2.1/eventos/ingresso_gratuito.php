<?php
  require '../verifica.php';
  if(isset($_SESSION['idUser']) && !empty($_SESSION['idUser'])):
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <title>TicketClick</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.0/jquery.min.js"></script>

    <link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/cookie.css">
    <link rel="stylesheet" href="../css/cookie2.css">
    <link rel="shortcut icon" sizes="250x100" href="../icons/icone-ticket.ico">

    <script>
            function goBack() {
                window.history.back()
            }
		</script>

  </head>
  <body>
  <header class="menu-nav">
    <nav class="container navbar navbar-expand-md navbar-dark">
      <a href="../index_convidado.php" class="navbar-brand">
        <img src="../img/ticketclick.svg" alt="TicketClick">
      </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Abrir Navegação">
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ml-auto">
        <a style="color: grey;" class="nav-link" href="">(Convidado)</a>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo $nomeUser; ?></a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
              <a class="dropdown-item" href="../perfil/perfil_convidado.php">Minha Conta</a>
              <a class="dropdown-item" href="../convidado/meusIngressos.php">Meus ingressos</a>
              <a class="dropdown-item" href="#">Promoções</a>
              <div class="dropdown-divider">
              </div>
              <a class="dropdown-item" href="sair.php">Sair</a>
            </div>
          </li>
        </ul>
      </div>
    </nav>
  </header>
  <a class="btn-menu btn ml-md-2" href="../index_convidado.php">Voltar</a>
    <section class="content">
        <div class="container">
            <div class="col-lg">
                <!-- general form elements -->
                <div class="card card-primary">
                    <div class="card-header">
                        <h3 class="card-title">Informações Básicas</h3>
                        <h6>Adicione as informações básicas para adquirir o ingresso do evento.</h6>
                    </div>
                    <!-- /.card-header -->
                    <!-- form start -->
                    <form role="form" action="enviar_email.php" method="post" enctype="multipart/form-data">
                        <div class="card-body">
                            <div class="form-group">
                                <div class="inline-block">
                                    <label for="exampleInputEmail1"><strong>Nome *</strong></label>
                                    <input type="text" class="form-control" maxlength="100" name="nome_ingresso" id="nome_ingresso" required>
                                </div>
                                <div class="inline-block">
                                    <div class="form-group">
                                    <label for="exampleInputEmail1"><strong>Sobrenome *</strong></label>
                                    <input type="text" class="form-control" name="sobrenome_ingresso" id="sobrenome_ingresso" required >
                                    </div>
                                </div>
                                <br>
                                <div class="inline-block">
                                    <div class="form-group">
                                    <label for="exampleInputEmail1"><strong>E-mail *</strong></label>
                                    <input type="text" class="form-control" name="email_ingresso" id="email_ingresso" required>  
                                    <br>
                                    <code>Os ingressos serão enviados neste e-mail!</code>
                                    </div>
                                </div>
                                <div class="inline-block">
                                    <div class="form-group">
                                    <label for="exampleInputEmail1"><strong>Confirmação de e-mail *</strong></label>
                                    <input type="text" class="form-control" name="email_confirmacao" id="email_confirmacao" required>
                                    <br>
                                    <code></code>
                                    </div>
                                </div>
                                <?php

                                include_once('../config.php');

                                $result_eventos = "SELECT * FROM cadastro_convidado WHERE ID_convidado = $idconvidadoUser";
                                $resultado_eventos = mysqli_query($conexao, $result_eventos);

                                $result = mysqli_query($conexao, "SELECT * FROM eventos WHERE ID_evento = 35");
                                $row = $result->fetch_assoc();

                                ?>

                                <input type="hidden" class="form-control" name="fk_ingressos_gratuito_convidado" id="fk_ingressos_gratuito_convidado" value="<?php echo $idconvidadoUser ?>" readonly required>
                                <input type="hidden" class="form-control" name="fk_ingressos_gratuito_eventos" id="fk_ingressos_gratuito_eventos" value="<?php echo $row['ID_evento'] ?>" readonly required>
                            <style>
                            .content {
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            }

                            .form-control {
                            padding: 10px 20px 10px 10px;
                            max-width: 500px;
                            }

                            .descricao_evento {
                            padding: 10px 20px 10px 10px;
                            max-width: 100%;
                            }

                            .descricao_local {
                            padding: 10px 20px 10px 10px;
                            max-width: 100%;
                            }

                            .inline-block {
                            width: 350px;
                            height: 100px;
                            display: inline-block;
                            }
                            </style>
                            </div>
                            <!-- <button style="float:center; border-radius: 8px; background-color: #29A47A; border-color: #29A47A" type="submit" name="button_adquirir" class="btn">Finalizar</button> -->
                            <input type="submit" value="Finalizar" class="btn btn-outline-success btn-lg btn-block">
                        </div>
                        </div>
                    </div>
                    </div>
                </div>
                </div>
                </div>
                          </body>
                          </html>
                          <?php else: header("Location: ../login_convidado.php"); endif; ?>
