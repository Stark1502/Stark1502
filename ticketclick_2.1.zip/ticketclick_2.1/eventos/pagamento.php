
<!DOCTYPE html>
<html lang="en">
  <head>

 <link rel="stylesheet" href="../js/comprar2.js/">
 <link rel="stylesheet" href="../css/pagamento.css/"> 




<div style="height: 303px; background: url('https://checkout.paystand.co/v2/demo/oneup-demo-hdr-bkg.jpg') center repeat-x;"></div>

<div style="text-align: center;">
  <div style="max-width: 800px; margin: 0 auto;">

    <div class="ps-chkout">
      <!-- Drop these script to add checkout widget -->
      <script type="text/javascript" id="paystand_checkout" src="https://checkout.paystand.co/v2/js/paystand.checkout.js"></script>
    </div>
    <img src="https://checkout.paystand.co/v2/demo/oneup_left-side.jpg" alt="left-img" class="img-responsive"></p>
</div>
</div>

<div>
  <p>&nbsp;</p>
  <hr>
  <p>&nbsp;</p>
</div>

<div class="container">
  <div class="row">
    <div class="col-lg-12">

      <h2>Docs:</h2>
      <p><a target="_blank" href="http://developers.paystand.com/docs/checkout-object">http://developers.paystand.com/docs/checkout-object</a>
      </p>
    </div>
  </div>
</div>
</html>