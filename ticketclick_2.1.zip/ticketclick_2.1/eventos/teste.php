<?php 

      include_once('../config.php');
      
      $ID_evento = $_POST['ID_evento'];
    //   $sobrenome_ingresso = $_POST['sobrenome_ingresso'];
    //   $email_ingresso = $_POST['email_ingresso'];
    //   $email_confirmacao = $_POST['email_confirmacao'];

      $result_eventos = "SELECT * FROM eventos WHERE ID_evento = '$ID_evento'";
      $resultado_eventos = mysqli_query($conexao, $result_eventos);
      $row_usuario = mysqli_fetch_assoc($resultado_eventos);

      

    ?>