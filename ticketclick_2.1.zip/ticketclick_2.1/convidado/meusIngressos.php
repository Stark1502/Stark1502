<?php
  require '../verifica.php';
  if(isset($_SESSION['idUser']) && !empty($_SESSION['idUser'])):
?>

<!DOCTYPE html>
<html>
  <head>
    <title>TicketClick - Meus ingressos</title>
    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css">

    <link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="shortcut icon" sizes="250x100" href="../icons/icone-ticket.ico">

    <script>
            function goBack() {
                window.history.back()
            }
		</script>
    
  </head>
  <body>
    <header class="menu-nav">
      <nav class="container navbar navbar-expand-md navbar-dark">
        <a href="../index_organizador.php" class="navbar-brand">
          <img src="../img/ticketclick.svg" alt="TicketClick">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Abrir Navegação">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto">
          <a style="color: grey;" class="nav-link" href="">(Convidado)</a>
            <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" style="float: right" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo $nomeUser; ?></a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="perfil/perfil_organizador.php">Minha Conta</a>
              <a class="dropdown-item" href="organizador/meusEventos.php">Meus Ingressos</a>
              <a class="dropdown-item" href="">Promoções</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="../sair.php">Sair</a>
            </div>
            </li>
          </ul>
        </div>  
      </nav>
    </header>
    <div class="container">
    <a class="btn-menu btn ml-md-2" href="../index_convidado.php">Voltar</a>
      <div class="row">
        <div class="col-sm-6 offset-md-3">
          <form method="POST">
            <h2>MEUS INGRESSOS</h2>
            <hr>
            <div class="inline-block">
              <h5>Ingressos: <?php

                include_once('../config.php');

                // $result = mysqli_query($conexao, "SELECT DISTINCT SUM(ID_evento) as Soma FROM eventos INNER JOIN cadastro_organizador WHERE nome = 'Pedro Henrique Pereira de Souza'");
                // $result = mysqli_query($conexao, "SELECT DISTINCT COUNT(ID_evento) as Soma FROM eventos A INNER JOIN cadastro_organizador B ON A.nome_organizador = B.nome;");
                $result = mysqli_query($conexao, "SELECT COUNT(ID_ingresso_gratuito) as Soma FROM ingressos_gratuito WHERE fk_ingressos_gratuito_convidado = $idconvidadoUser");
                $row = $result->fetch_assoc();
                echo $row['Soma'];
              ?>.</h5>
            </div>
            <div class="inline-block">
              <!-- <a id="imagem_evento" class="btn-menu btn ml-md-2" href="cadastro_evento.php">Criar evento</a> -->
              <style>
                #imagem_evento {
                  position:absolute;
                  top:110px;
                  left:300px;
                  height:35px;
                }

                .imagem_evento {
                  width:100%;
                }
              </style>
            </div>
          </form> 
        </div>
      </div>
      <style>
        .inline-block {
          display: inline-block;
          margin-bottom: 40px;
        }
      </style>
      <section class="container eventos">
      <style>
        .imagem_evento {
          width:100%;
        }
      </style>
      <div class="row">
        <?php

          include_once('../config.php');

          $result_eventos = "SELECT * FROM eventos as a INNER JOIN ingressos_gratuito as b WHERE b.fk_ingressos_gratuito_eventos = a.ID_evento;";
          $resultado_eventos = mysqli_query($conexao, $result_eventos);
          
        ?>
                <style>
                  .inline-block {
                    display: inline-block;
                    margin-top: 40px;
                  }
              </style>
            <br>
            
            <div class="row">
            <div class="col-sm-6 offset-md-3">
            <?php while($row_usuario = mysqli_fetch_assoc($resultado_eventos)) { ?>
                <form method="POST">
                  <div class="col-md">
                    <div class="card">
                      <div class="card-header">
                        <h3 class="card-title"></h3>
                        <h3 class="card-title"><center><?php echo $row_usuario['nome_evento'];?></h3></center>
                      </div>
                      <!-- /.card-header -->
                      <div class="card-body p-1" style="text-align: center; margin-bottom: 10px; width: 100%">
                        <center><img src="../img/<?php echo $row_usuario['foto_evento'];?>" alt="Imagem do evento..." style="width: 250px; border-radius: 6px; margin-top: 20px"></center>
                        <br></a>
                        <br>
                        <strong><p style="color: #2D1E41" class="card-text"><i class="fas fa-calendar me-1"></i><?php echo $row_usuario['data_inicio'];?> > <?php echo $row_usuario['data_termino'];?>               |
                        <i class="fas fa-bell me-1"></i><?php echo $row_usuario['hora_inicio'];?> : <?php echo $row_usuario['hora_termino'];?></p></p></strong>
                        <br>

                        <h4 style="text-align: center"><?php echo $row_usuario['descricao'];?></h4>
                        <h6 style="text-align: center"><?php echo $row_usuario['rua']?>, <?php echo $row_usuario['bairro']?>, <?php echo $row_usuario['numero']?>, <?php echo $row_usuario['cidade']?>, <?php echo $row_usuario['estado']?>.</h6>
                        <div class="inline-block">
                          <center><code>Leia o QR Code abaixo para validar o seu ingresso.</code></center>
                        </div>
                        <div class="inline-block">
                          <center><img src="../img/ticketclick_validacao.png" alt="QR Code" style="width: 250px; border-radius: 6px; margin-top: 20px"></center>
                        </div>
                        <br>
                        <style>
                          .inline-block {
                            display: inline-block;
                            margin-top: 20px;
                          }
                      </style>
                        <div class="inline-block">
                          <a class="btn btn-warning" href="../eventos/lollapalooza.php">Ver página do evento</a>
                        </div>
                        <?php

                        if(isset($_POST["button_deletar"])) {
                          
                          $result = mysqli_query($conexao, "SELECT * FROM ingressos_gratuito");
                          $row = $result->fetch_assoc();
                          $soma_delete = $row['ID_ingresso_gratuito'];
                          $result_delete = mysqli_query($conexao, "DELETE FROM ingressos_gratuito WHERE ID_ingresso_gratuito = $soma_delete");
                          echo "<script>alert('Evento deletado com sucesso!');location.href=\"meusEventos.php\";</script>";
                        }else{
                          echo "<script>alert('Erro!);location.href=\"meusEventos.php\";</script>";
                        }
                        ?>

                        <div class="inline-block">
                          <button type="button_deletar" name="button_deletar" class="btn btn-danger">Apagar ingresso</button>
                        </div>
                        <style>
                          .inline-block {
                            display: inline-block;
                            margin-top: 20px;
                          }
                        </style>
                      </div>
                      <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                  </div>
                  <br>
                  <?php 
                    } 
                    ?>
                </form>
              </div>
            </div>
        </section>
    </body>
    <script type="text/javascript" src="../js/meusEventos.js"></script>
    <script>
		function goBack() {
			window.history.back()
		}
		</script>
</html>

<?php else: header("Location: ../login_convidado.php"); endif; ?>