<?php
include_once("../config.php");

    function verifica_validacao($conexao){
        if(isset($_POST['enviar']) && $_POST['enviar'] == "valida") {
            $id = addslashes($_POST['ID']);
            $sql = $conexao->prepare("SELECT * FROM ingressos_gratuito WHERE fk_ingressos_gratuito_convidado = ?");
            $sql->bind_param("s", $id);
			$sql->execute();
			$get = $sql->get_result();
			$total = $get->num_rows;

            if($total > 0){
				$dados = $get->fetch_assoc();
                add_dados_valida($conexao, $id);

			}else{
                echo "<br><div class='alert alert-danger w-50 p-3 offset-md-3'>Erro ao validar o ingresso!</div>";
			}
        }
    }

    function add_dados_valida($conexao, $id) {
        $validado = 'Sim';
        $sql = $conexao->prepare("UPDATE ingressos_gratuito SET validado = ? WHERE fk_ingressos_gratuito_convidado = ?");
        $sql->bind_param("ss", $validado, $id);
        $sql->execute();

        if($sql->affected_rows > 0) {
            echo "<br><div class='alert alert-success w-50 p-3 offset-md-3'>Seu ingresso foi validado com sucesso!</div>";
		}else{
            echo "<br><div class='alert alert-danger w-50 p-3 offset-md-3'>O ingresso já foi validado!</div>";
        }
    }

?>