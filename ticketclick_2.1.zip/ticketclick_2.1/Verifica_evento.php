<?php

require 'perfil/conexao.php';

if(isset($_SESSION['idUser']) && !empty($_SESSION['idUser'])) {
    
    require_once 'Usuario_class_evento.php';
    $u = new Usuario2(); 

    $listIdevento = $u->idevento_usuario($_SESSION['idUser']);
    $ideventoUser = $listIdevento['ID_evento'];

} 