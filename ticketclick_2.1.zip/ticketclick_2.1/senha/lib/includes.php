<?php

    include_once("config.php");
    include_once("settings.php");
    include_once("functions.php");

?>