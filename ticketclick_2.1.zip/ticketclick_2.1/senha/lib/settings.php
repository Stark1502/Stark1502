<?php

    define("ticketclickdir", "http://ticketclick.ml/senha");

?>