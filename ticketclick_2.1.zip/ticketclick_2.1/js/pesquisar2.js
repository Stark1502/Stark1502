function pesquisar() {
    var input, filtro, menu, menuItens, links;
    input = document.getElementById("txtBusca");
    filtro = input.value.toUpperCase();
    menu = document.getElementById("menu");
    menuItens = menu.getElementsByTagName("tr");
    for(var i=0; i<menuItens.length; i++) {
        links = menuItens[i].getElementsByTagName("td")[0];
        if(links.innerHTML.toUpperCase().indexOf(filtro)>-1) {
            menuItens[i].style.display="";
        }else{
            menuItens[i].style.display="none";
        }
    }
}